# JavaCucumber
To Execute the automation scripts:

1. Clone the project from git and import it into Eclipse
2. clean and Build the Maven project
3. Right-click the TestRunner.java file under com.runners package in src/test/java folder
4. Add the tags to the TestRunner file
5. Right-click and Run As "JUnit Test"


