package Stepdefination;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.*;

public class Googlesearchsteps {

	WebDriver driver =null;

	@Given("user open browser")
	public void user_open_browser() {
		System.out.println("Inside Step -  user_open_browser ");

		System.setProperty("webdriver.chrome.driver", "D:\\\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.navigate().to("https://www.google.com/");
	}

	@When("user is on the googleseach page")
	public void user_is_on_the_googleseach_page() {
		System.out.println("Inside Step -  user_open_browser ");

	}

	@And("User enters a text in search box")
	public void user_enters_a_text_in_search_box() {
		System.out.println("Inside Step -  user_enters_a_text_in_search_box ");

	}

	@And("user click on search button")
	public void user_click_on_search_button() {
		System.out.println("Inside Step -  user_click_on_search_button ");

	}

	@Then("user is navigate to search page")
	public void user_is_navigate_to_search_page() {
		System.out.println("Inside Step -  user_is_navigate_to_search_page ");


	}}
