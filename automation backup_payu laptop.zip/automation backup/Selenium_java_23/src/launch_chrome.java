import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class launch_chrome {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.google.com/");
		
		//driver.findElement(By.xpath("//textarea[@name=\"q\"]"));
		driver.findElement(By.xpath("//div[@class='FPdoLc lJ9FBc']//following::input[2][@value=\"I'm Feeling Lucky\"]")).click();
	
	driver.close();
	}
	

}
