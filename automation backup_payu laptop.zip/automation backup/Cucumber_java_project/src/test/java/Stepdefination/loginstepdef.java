package Stepdefination;

import io.cucumber.java.en.*;

public class loginstepdef {
	@Given("User is on login screen")
	public void user_is_on_login_screen() {
	    System.out.println("Inside Step- Browser is open");
	}

	@When("User enters valid username and password")
	public void user_enters_valid_username_and_password() {
		 System.out.println("Inside Step- User enters valid username and password");
	}

	@And("clicks on the login button")
	public void clicks_on_the_login_button() {
		System.out.println("Inside Step-clicks on the login button");
		
	}

	@Then("User is navigated to home page")
	public void user_is_navigated_to_home_page() {
		System.out.println("Inside Step-User is navigated to home page");
  
	}
}
