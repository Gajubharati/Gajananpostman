package Testrunner;


import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions( features ="src/test/resources/Features/login.feature", glue={"Stepdefination/loginstepdef"},
monochrome = true,
plugin = {"pretty","html:target/HtmlReports/report"}

)
public class logintestrunner {


}
